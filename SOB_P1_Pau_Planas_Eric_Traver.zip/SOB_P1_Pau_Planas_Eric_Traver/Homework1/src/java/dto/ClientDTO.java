package dto;

import authn.Client;
import java.util.HashMap;
import java.util.Map;

public class ClientDTO {
    // Datos públicos
    public int id;
    public String username;
    public boolean privilegis;
    
    // El requisito HATEOAS
    public Map<String, String> links = new HashMap<>();

    public ClientDTO(Client c) {
        this.id = c.getClient_id();
        this.username = c.getUser();
        this.privilegis = c.isPrivilegis();
        // NOTA: No copiamos la contraseña, así cumplimos el requisito de privacidad
    }
    
    public void addLink(String key, String url) {
        this.links.put(key, url);
    }
}
