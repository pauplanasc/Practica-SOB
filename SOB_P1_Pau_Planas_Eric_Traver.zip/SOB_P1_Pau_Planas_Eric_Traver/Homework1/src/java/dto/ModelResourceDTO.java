/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.*;



public class ModelResourceDTO {
    private int model_id;
    private String proveidor;
    private List<String> capacitatsNom;
    private String llicenciaNom;
    private Long longitud;
    private Date data_entrenament;
    private Date last_actualitzacio;
    private Float versio;
    private String nom;
    private String descripcio;
    private String descripcio_curta;
    private int llenguatges;

    public ModelResourceDTO(){
        
    }

    public ModelResourceDTO(int model_id, String proveidor, List<String> capacitatsNom, String llicenciaNom, Long longitud, Date data_entrenament, Date last_actualitzacio, Float versio, String nom, String descripcio, String descripcio_curta, int llenguatges) {
        this.model_id = model_id;
        this.proveidor = proveidor;
        this.capacitatsNom = capacitatsNom;
        this.llicenciaNom = llicenciaNom;
        this.longitud = longitud;
        this.data_entrenament = data_entrenament;
        this.last_actualitzacio = last_actualitzacio;
        this.versio = versio;
        this.nom = nom;
        this.descripcio = descripcio;
        this.descripcio_curta = descripcio_curta;
        this.llenguatges = llenguatges;
    }
    
    
    public int getModel_id() {
        return model_id;
    }

    public String getProveidorNom() {
        return proveidor;
    }

    public List<String> getCapacitatsNom() {
        return capacitatsNom;
    }

    public String getLlicenciaNom() {
        return llicenciaNom;
    }

    public Long getLongitud() {
        return longitud;
    }

    public Date getData_entrenament() {
        return data_entrenament;
    }

    public Date getLast_actualitzacio() {
        return last_actualitzacio;
    }

    public Float getVersio() {
        return versio;
    }

    public String getNom() {
        return nom;
    }

    public String getDescripcio() {
        return descripcio;
    }

    public int getLlenguatges() {
        return llenguatges;
    }

    public String getDescripcio_curta() {
        return descripcio_curta;
    }
    
    public void setModel_id(int model_id) {
        this.model_id = model_id;
    }

    public void setProveidorNom(String proveidor) {
        this.proveidor = proveidor;
    }

    public void setCapacitatsNom(List<String> capacitatsNom) {
        this.capacitatsNom = capacitatsNom;
    }

    public void setLlicenciaNom(String llicenciaNom) {
        this.llicenciaNom = llicenciaNom;
    }

    public void setLongitud(Long longitud) {
        this.longitud = longitud;
    }

    public void setData_entrenament(Date data_entrenament) {
        this.data_entrenament = data_entrenament;
    }

    public void setLast_actualitzacio(Date last_actualitzacio) {
        this.last_actualitzacio = last_actualitzacio;
    }

    public void setVersio(Float versio) {
        this.versio = versio;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    public void setLlenguatges(int llenguatges) {
        this.llenguatges = llenguatges;
    }

    public void setDescripcio_curta(String descripcio_curta) {
        this.descripcio_curta = descripcio_curta;
    }
    
    
}
