/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

public class ModelResourceDTOCurt {
    private int model_id;
    private String nom;
    private String descripcio_curta;
    private String logo;
    private String capacitatNom;

    public ModelResourceDTOCurt(int model_id, String nom, String descripcio_curta,String logo, String capacitatNom) {
        this.model_id = model_id;
        this.nom = nom;
        this.descripcio_curta = descripcio_curta;
        this.logo = logo;
        this.capacitatNom = capacitatNom;
    }

    public int getModel_id() {
        return model_id;
    }
       
    public String getNom() {
        return nom;
    }

    public String getDescripcio_curta() {
        return descripcio_curta;
    }

    public String getlogo() {
        return logo;
    }
    
    public String getCapacitatNom() {
        return capacitatNom;
    }

    public void setModel_id(int model_id) {
        this.model_id = model_id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDescripcio_curta(String descripcio_curta) {
        this.descripcio_curta = descripcio_curta;
    }

    public void setCapacitatNom(String capacitatNom) {
        this.capacitatNom = capacitatNom;
    }

    public void setlogo(String logo) {
        this.logo = logo;
    }
        
}

