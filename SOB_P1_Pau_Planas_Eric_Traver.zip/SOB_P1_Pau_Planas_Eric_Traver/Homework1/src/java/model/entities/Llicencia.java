/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.entities;

import java.io.*;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
public class Llicencia implements Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="Model_Llic", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Model_Llic") 
    private int llicencia_id;
    private String nom;
    private String tipus;
    private String permisos;
    private String restriccions;

    public int getLlicencia_id() {
        return llicencia_id;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getNom() {
        return nom;
    }

    public String getTipus() {
        return tipus;
    }

    public String getPermisos() {
        return permisos;
    }

    public String getRestriccions() {
        return restriccions;
    }

    public void setLlicencia_id(int llicencia_id) {
        this.llicencia_id = llicencia_id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setTipus(String tipus) {
        this.tipus = tipus;
    }

    public void setPermisos(String permisos) {
        this.permisos = permisos;
    }

    public void setRestriccions(String restriccions) {
        this.restriccions = restriccions;
    }
    
    
    
}
