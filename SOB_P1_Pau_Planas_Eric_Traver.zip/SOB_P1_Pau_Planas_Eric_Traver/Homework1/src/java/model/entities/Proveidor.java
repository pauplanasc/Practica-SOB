/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.entities;

import java.util.*;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@XmlRootElement
public class Proveidor implements Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="Model_Prov", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Model_Prov") 
    private int proveidor_id;
    private String nom;
    private String rutaLogo;
    private String URL;
    private int anyCreacio;
    
    // Les dades es carreguen desde el costat principal de la relacio, es a dir, modelResource
    @OneToMany(mappedBy="proveidor")
    private List<ModelResource> models;
  
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getProveidor_id() {
        return proveidor_id;
    }

    public String getRutaLogo() {
        return rutaLogo;
    }

    public String getURL() {
        return URL;
    }

    public int getAnyCreacio() {
        return anyCreacio;
    }

    public List<ModelResource> getModels() {
        return models;
    }
       
    public String getNom() {
        return nom;
    }
        
    public void setProveidor_id(int proveidor_id) {
        this.proveidor_id = proveidor_id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setRutaLogo(String rutaLogo) {
        this.rutaLogo = rutaLogo;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public void setAnyCreacio(int anyCreacio) {
        this.anyCreacio = anyCreacio;
    }

    public void setModels(List<ModelResource> models) {
        this.models = models;
    }
    
    
    
    
}
