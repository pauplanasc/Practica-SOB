package model.entities; // O tu paquete correspondiente

import authn.*;
import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.*;

@Entity
@NamedQuery(
    name = "AccessLog.findLastByUser", 
    query = "SELECT a FROM AccessLog a WHERE a.id = (SELECT MAX(a2.id) FROM AccessLog a2 WHERE a2.client.client_id = :userId)"
)
public class AccessLog implements Serializable {

    @Id
    @SequenceGenerator(name="AccessLog_Gen", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AccessLog_Gen")
    private Long id;

    @ManyToOne
    private Client client; // Quién visitó

    @ManyToOne
    private ModelResource model; // Qué modelo visitó

    public AccessLog() {}

    public AccessLog(Client client, ModelResource model) {
        this.client = client;
        this.model = model;
    }

    // Getters y Setters
    public Long getId() { 
        return id; 
    }
    
    public void setId(Long id) { 
        this.id = id; 
    }
    public Client getClient() { 
        return client; 
    }
        
    public void setClient(Client client) { 
        this.client = client; 
    }
    
    public ModelResource getModel() { return model; 
    }
    
    public void setModel(ModelResource model) { 
        this.model = model; 
    }
    
}
