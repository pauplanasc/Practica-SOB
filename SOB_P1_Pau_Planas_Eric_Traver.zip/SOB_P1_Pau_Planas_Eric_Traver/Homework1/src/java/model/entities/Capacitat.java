/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.entities;

import jakarta.persistence.*;
import java.util.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@XmlRootElement
public class Capacitat implements Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="Model_Capac", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Model_Capac") 
    private int capacitat_id;
    private String nom;
    private int imaginacio;
    private int precisio;
    private int raonament;
    
    @ManyToMany(mappedBy="capacitats")
    private List <ModelResource> llista_models;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getCapacitat_id() {
        return capacitat_id;
    }

    public List<ModelResource> getLlista_models() {
        return llista_models;
    }
    
    public String getNom() {
        return nom;
    }

    public int getImaginacio() {
        return imaginacio;
    }

    public int getPrecisio() {
        return precisio;
    }

    public int getRaonament() {
        return raonament;
    }
    
    public void setCapacitat_id(int capacitat_id) {
        this.capacitat_id = capacitat_id;
    }

    public void setLlista_models(List<ModelResource> llista_models) {
        this.llista_models = llista_models;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setImaginacio(int imaginacio) {
        this.imaginacio = imaginacio;
    }

    public void setPrecisio(int precisio) {
        this.precisio = precisio;
    }

    public void setRaonament(int raonament) {
        this.raonament = raonament;
    }
    
    
}
