/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.entities;

import jakarta.persistence.*;
import java.util.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@XmlRootElement
public class ModelResource implements Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="Model_Gen", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Model_Gen") 
    private int model_id;
    
    /* Bidireccional */ 
    @ManyToOne
    @JoinColumn(name="proveidor_id")
    private Proveidor proveidor;
    
    /* Bidireccional */
    @ManyToMany
    @JoinTable(name = "model_capacitat", joinColumns = @JoinColumn(name = "model_id"), inverseJoinColumns =
    @JoinColumn(name = "capacitat_id"))
     List <Capacitat> capacitats;
    
    /* Unidireccional */
    @ManyToOne
    @JoinColumn(name="llicencia_id")
    private Llicencia llicencies;
    
    private Long longitud;
    private Date data_entrenament;
    private Date last_actualitzacio;
    private Float versio;
    private String nom;
    private String descripcio;
    private String descripcio_curta;
    private int llenguatges;
    private boolean privat;

    public ModelResource(){
        
    }
               
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {
        return model_id;
    }

    public Proveidor getProveidor() {
        return proveidor;
    }

    public List<Capacitat> getCapacitats() {
        return capacitats;
    }

    public Llicencia getLlicencies() {
        return llicencies;
    }

    public Long getLongitud() {
        return longitud;
    }

    public Date getData_entrenament() {
        return data_entrenament;
    }

    public Date getLast_actualitzacio() {
        return last_actualitzacio;
    }

    public Float getVersio() {
        return versio;
    }

    public String getNom() {
        return nom;
    }

    public String getDescripcio() {
        return descripcio;
    }

    public int getLlenguatges() {
        return llenguatges;
    }

    public int getModel_id() {
        return model_id;
    }

    public boolean isPrivat() {
        return privat;
    }

    public String getDescripcio_curta() {
        return descripcio_curta;
    }
    
    public void setId(int id) {
        this.model_id = id;
    }

    public void setProveidor(Proveidor proveidor) {
        this.proveidor = proveidor;
    }

    public void setCapacitat(List<Capacitat> capacitats) {
        this.capacitats = capacitats;
    }

    public void setLlicencia(Llicencia llicencies) {
        this.llicencies = llicencies;
    }

    public void setLongitud(Long longitud) {
        this.longitud = longitud;
    }

    public void setData_entrenament(Date data_entrenament) {
        this.data_entrenament = data_entrenament;
    }

    public void setLast_actualitzacio(Date last_actualitzacio) {
        this.last_actualitzacio = last_actualitzacio;
    }
    
    public void setVersio(Float versio) {
        this.versio = versio;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    public void setLlenguatges(int llenguatges) {
        this.llenguatges = llenguatges;
    }

    public void setModel_id(int model_id) {
        this.model_id = model_id;
    }

    public void setCapacitats(List<Capacitat> capacitats) {
        this.capacitats = capacitats;
    }

    public void setLlicencies(Llicencia llicencies) {
        this.llicencies = llicencies;
    }

    public void setPrivat(boolean privat) {
        this.privat = privat;
    }

    public void setDescripcio_curta(String descripcio_curta) {
        this.descripcio_curta = descripcio_curta;
    }    
    
}
