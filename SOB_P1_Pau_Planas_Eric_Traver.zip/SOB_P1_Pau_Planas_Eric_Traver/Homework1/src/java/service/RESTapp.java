package service;

import jakarta.ws.rs.core.Application;

@jakarta.ws.rs.ApplicationPath("rest/api/v1")
public class RESTapp extends Application {
    
}
