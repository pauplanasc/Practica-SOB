/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import authn.Client;
import dto.*;
import java.util.*;
import java.util.List;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import model.entities.*;
import authn.Secured;
import jakarta.persistence.TypedQuery;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import model.entities.Capacitat;

@Stateless
@Path("models")
public class ModelFacadeREST extends AbstractFacade <ModelResource>{
    
    @PersistenceContext(unitName = "sob_grup_21PU")
    private EntityManager em;
    
    private Response resposta;
    private String consulta;

    public ModelFacadeREST() {
        super(ModelResource.class);
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModels(@QueryParam("capability") List<String> capa, @QueryParam("provider") String prov){
        
        consulta = "SELECT m FROM ModelResource m ";
        TypedQuery<ModelResource> query;
        List<ModelResource> models;
        
        if (!capa.isEmpty() && prov == null){
            consulta = consulta + "JOIN m.capacitats c WHERE c.nom IN :capability GROUP BY m HAVING COUNT (DISTINCT c.nom) = " + capa.size() + " ";
        }
        
        if (prov != null && capa.isEmpty()){
            consulta = consulta + "JOIN m.proveidor p WHERE p.nom = :provider ";   
        }
        
        if (prov != null && !capa.isEmpty()){
            consulta = consulta + "JOIN m.capacitats c JOIN m.proveidor p WHERE p.nom = :provider AND c.nom IN :capability GROUP BY m HAVING COUNT (DISTINCT c.nom) = " + capa.size() + " ";
        }
        
        consulta = consulta + "ORDER BY m.nom ";
        
        query = em.createQuery(consulta,ModelResource.class);

        if (!capa.isEmpty() && prov == null){
            query.setParameter("capability", capa);
        }
        
        if (prov != null && capa.isEmpty()){
            query.setParameter("provider", prov);           
        }
        
        if (prov != null && !capa.isEmpty()){
            query.setParameter("provider", prov);
            query.setParameter("capability", capa); 
        }
        
        models = query.getResultList();
        List<ModelResourceDTOCurt> modelsDTO = models.stream().map(this::toDTOCurt).toList();
        resposta = Response.ok().entity(modelsDTO).build();
        return resposta;
    }
    
    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getModelperId(@PathParam("id") int id, ContainerRequestContext requestCtx){
        try{
            AccessLog resultat = new AccessLog();
            String username;
            consulta = "SELECT m FROM ModelResource m WHERE m.model_id = :model_id";
            ModelResource model = em.createQuery(consulta, ModelResource.class).setParameter("model_id", id) .getSingleResult();
            ModelResourceDTO modelDTO = this.toDTO(model);
            resposta = Response.ok().entity(modelDTO).build();
            List<String> headers = requestCtx.getHeaders()
                        .get(HttpHeaders.AUTHORIZATION);
            String auth = headers.get(0);
            auth = auth.replace("Basic ", "");
            String decode = com.sun.xml.messaging.saaj.util.Base64.base64Decode(auth);
            StringTokenizer tokenizer = new StringTokenizer(decode, ":");
            username = tokenizer.nextToken();
            TypedQuery<Client> query = em.createNamedQuery("Client.findUser", Client.class);
            Client c = query.setParameter("user", username)
                            .getSingleResult();
            resultat.setClient(c);
            resultat.setModel(model);
            em.persist(resultat);
        }
        catch(jakarta.persistence.NoResultException e){
            resposta = Response.noContent().build();
        }
        return resposta;
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured
    public Response crearModel(ModelResourceDTO m){
        try{
            ModelResource resultat = this.toOTD(m);
            em.persist(resultat);
            resposta = Response.status(Response.Status.CREATED).entity(resultat.getId()).build();
        }
        catch (jakarta.persistence.EntityExistsException | IllegalArgumentException e){
            resposta = Response.status(Response.Status.NOT_ACCEPTABLE).build();
        }
        return resposta;
    }
    
    @DELETE
    @Path("{id}")
    @Secured
    public Response remove(@PathParam("id") Long id){
        try{
        consulta = "SELECT m FROM ModelResource m WHERE m.model_id = :model_id";
        ModelResource model = em.createQuery(consulta,ModelResource.class).setParameter("model_id", id).getSingleResult();
        em.remove(model);
        resposta = Response.ok().build();
        }
        catch (IllegalArgumentException | jakarta.persistence.NoResultException e){
            resposta = Response.noContent().build();
        }
        return resposta;
    }
    
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    private ModelResourceDTO toDTO (ModelResource m){
        List <String> capacitatsNom = m.getCapacitats().stream()
                .map(Capacitat::getNom)
                .toList();

        return new ModelResourceDTO(m.getId(),  m.getProveidor().getNom(), capacitatsNom,
                                    m.getLlicencies().getNom(), m.getLongitud(), m.getData_entrenament(),
                                    m.getLast_actualitzacio(), m.getVersio(), m.getNom(), m.getDescripcio(), m.getDescripcio_curta(),m.getLlenguatges());
    }
    
    private ModelResourceDTOCurt toDTOCurt (ModelResource m){
        List <String> capacitatsNom = m.getCapacitats().stream()
                .map(Capacitat::getNom)
                .toList();
        return new ModelResourceDTOCurt(m.getId(), m.getNom(), m.getDescripcio_curta(), m.getProveidor().getRutaLogo(),capacitatsNom.get(0));
    }
    
    private ModelResource toOTD (ModelResourceDTO m){
        
        ModelResource resultat = new ModelResource();
        
        try{
        // Buscar Proveidor a partir de nom
        consulta = "SELECT p FROM Proveidor p WHERE p.nom = :proveidorNom";
        Proveidor proveidor = em.createQuery(consulta, Proveidor.class).setParameter("proveidorNom", m.getProveidorNom()).getSingleResult();
        
        // Buscar Llicencia a partir de nom
        consulta = "SELECT l FROM Llicencia l WHERE l.nom = :llicenciaNom";
        Llicencia llicencia = em.createQuery(consulta, Llicencia.class).setParameter("llicenciaNom", m.getLlicenciaNom()).getSingleResult();
             
        // Buscar llista de capacitats a partir de llista de nom
        consulta = "SELECT c FROM Capacitat c WHERE c.nom IN :capacitatNom";
        List <Capacitat> capacitats = em.createQuery(consulta, Capacitat.class).setParameter("capacitatNom", m.getCapacitatsNom()).getResultList();
        
        
        resultat.setNom(m.getNom());
        resultat.setData_entrenament(m.getData_entrenament());
        resultat.setDescripcio(m.getDescripcio());
        resultat.setLast_actualitzacio(m.getLast_actualitzacio());
        resultat.setLlenguatges(m.getLlenguatges());
        resultat.setLlicencia(llicencia);
        resultat.setLongitud(m.getLongitud());
        resultat.setVersio(m.getVersio());
        resultat.setProveidor(proveidor);
        resultat.setCapacitat(capacitats);
        
        if(proveidor == null || llicencia == null){
            resultat = null;
        }
        
        return resultat;
        
        }
        catch (jakarta.persistence.NoResultException e){
            throw new RuntimeException("No se encontró el proveidor: " + m.getProveidorNom() + " O la llicencia: " + m.getLlicenciaNom());
        }
        catch (jakarta.persistence.NonUniqueResultException e) {
            throw new RuntimeException("Más de un proveidor con el nombre: " + m.getNom());
        }

    }

}
