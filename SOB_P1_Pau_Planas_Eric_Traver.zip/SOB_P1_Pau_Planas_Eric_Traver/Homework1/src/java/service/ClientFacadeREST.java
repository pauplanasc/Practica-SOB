package service;
import java.util.List;
import jakarta.ejb.Stateless;
import jakarta.persistence.PersistenceContext;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import authn.Client;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import model.entities.AccessLog;
import model.entities.ModelResource;
import dto.ClientDTO;

@Stateless
@Path("customer")
public class ClientFacadeREST extends AbstractFacade{
    
    @PersistenceContext(unitName = "sob_grup_21PU")
    private EntityManager em;
    
    public ClientFacadeREST() {
        super(Client.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Client> findAllClients(){
       TypedQuery<Client> query = em.createNamedQuery("Client.findAll", Client.class);
       return query.getResultList();
    }   
    
    /**
     * GET /rest/api/v1/customer/{id}
     * Devuelve info del cliente + Link al último modelo visto.
     */
    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findClientById(@PathParam("id") Integer id) {
        
        // 1. Buscar el cliente (Usando el método del padre AbstractFacade)
        Client client = (Client) super.find(id);
        
        if (client == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        // 2. Crear el DTO (Esto ya oculta la contraseña)
        ClientDTO dto = new ClientDTO(client);

        // 3. LOGICA HATEOAS con NAMED QUERY
        try {
            TypedQuery<AccessLog> query = em.createNamedQuery("AccessLog.findLastByUser", AccessLog.class);
            query.setParameter("userId", id);
            query.setMaxResults(1); // ¡Truco! Solo queremos el último, no toda la lista.

            List<AccessLog> logs = query.getResultList();
            
            if (!logs.isEmpty()) {
                // Si encontramos historial, sacamos el ID del modelo
                ModelResource lastModel = logs.get(0).getModel();
                // Añadimos el link al JSON
                dto.addLink("model", "/models/" + lastModel.getId());
            }

        } catch (Exception e) {
            e.printStackTrace(); // Si falla el log, no rompemos la respuesta principal
        }

        return Response.ok(dto).build();
    }
}
