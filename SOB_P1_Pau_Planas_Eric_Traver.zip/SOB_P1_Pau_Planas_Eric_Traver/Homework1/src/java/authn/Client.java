package authn;


import jakarta.json.bind.annotation.JsonbTransient;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;



@NamedQuery(
        name= "Client.findAll", 
        query= "SELECT c FROM Client c"
)
@NamedQuery(name="Client.findUser", 
            query="SELECT c FROM Client c WHERE c.user = :user")
@Entity
@XmlRootElement
public class Client implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name="Client_Gen", sequenceName="CLIENT_GEN", allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Client_Gen") 
    private int client_id;
    
    @Column(name="USERNAME")
    private String user;
    private String contrasenya;
    private boolean privilegis;

    public int getClient_id() {
        return client_id;
    }

    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    public String getUser() {
        return user;
    }
    
    @JsonbTransient
    public String getContrasenya() {
        return contrasenya;
    }

    public boolean isPrivilegis() {
        return privilegis;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public void setPrivilegis(boolean privilegis) {
        this.privilegis = privilegis;
    }
    
    
}
